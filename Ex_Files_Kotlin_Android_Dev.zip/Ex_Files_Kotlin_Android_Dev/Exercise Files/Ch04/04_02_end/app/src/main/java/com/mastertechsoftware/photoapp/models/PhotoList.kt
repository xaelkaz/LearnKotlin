package com.mastertechsoftware.photoapp.models

/**
 *
 */
data class PhotoList(val hits: List<Photo>) {
}